//
//  Essential C++
//      Stanley Lippman
//      Chen Chen @ November 26th, 2014
//
 
int my_main(int argc, char *argv[]) {} //The program will not work without main().
