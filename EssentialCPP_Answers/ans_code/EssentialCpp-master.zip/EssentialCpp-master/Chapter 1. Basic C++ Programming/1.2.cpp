//
//  Essential C++
//      Stanley Lippman
//      Chen Chen @ November 26th, 2014
//
 
//#include <string>

	string userName; //string is unrecognized.


//using namespace std;

	cout << "Please enter your first name: "; //cout is unrecognized.
	cin >> userName; //cin is unrecognized.
	cout << endl << "Hello, " << userName << "... and goodbye!" << endl; //cout is unrecognized.