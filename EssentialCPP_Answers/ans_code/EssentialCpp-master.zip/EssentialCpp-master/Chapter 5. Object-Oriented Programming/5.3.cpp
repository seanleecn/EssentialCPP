//
//  Essential C++
//      Stanley Lippman
//      Chen Chen @ December 29th, 2014
//

Reflects an is-a relationship:
(a)
(c)
(d)
(f)
(g)


Not reflects an is-a relationship:
(b)
(e)
(h)
(i)