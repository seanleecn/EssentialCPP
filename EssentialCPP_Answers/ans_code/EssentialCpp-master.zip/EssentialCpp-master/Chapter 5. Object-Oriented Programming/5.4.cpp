//
//  Essential C++
//      Stanley Lippman
//      Chen Chen @ December 29th, 2014
//

Library Material
	book
		audio book
		rental book
		CD-ROM book
	record
	children's puppet
	video
	video game
		Sega video game
		Sony Playstation video game
		Nintendo video game